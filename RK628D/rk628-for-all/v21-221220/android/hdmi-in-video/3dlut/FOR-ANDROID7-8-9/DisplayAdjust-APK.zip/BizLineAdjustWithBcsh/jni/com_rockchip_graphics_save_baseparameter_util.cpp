//
// Created by ly on 2018/7/17.
//
#include <stdio.h>
#include <fcntl.h>
#include <cutils/properties.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <cutils/log.h>
#include <xf86drm.h>
#include <xf86drmMode.h>
#include <com_rockchip_graphics_save_baseparameter_util.h>

#define BASE_OFFSET 8*1024
#define BACKUP_OFFSET 512*1024
#define TEST_BASE_PARMARTER
#define DEFAULT_BRIGHTNESS  50
#define DEFAULT_CONTRAST  50
#define DEFAULT_SATURATION  50
#define DEFAULT_HUE  50

#define BUFFER_LENGTH    256
#define RESOLUTION_AUTO 1<<0
#define COLOR_AUTO (1<<1)
#define HDCP1X_EN (1<<2)
#define RESOLUTION_WHITE_EN (1<<3)
#define LUT_SIZE 1024
#define BASEPARAMETER_IMAGE_SIZE 1024*1024

#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG , "outputImage", __VA_ARGS__)    // DEBUG

enum {
    HWC_DISPLAY_PRIMARY     = 0,
    HWC_DISPLAY_EXTERNAL    = 1,    // HDMI, DP, etc.
    HWC_DISPLAY_VIRTUAL     = 2,

    HWC_NUM_PHYSICAL_DISPLAY_TYPES = 2,
    HWC_NUM_DISPLAY_TYPES          = 3,
};
enum {
    HWC_DISPLAY_PRIMARY_BIT     = 1 << HWC_DISPLAY_PRIMARY,
    HWC_DISPLAY_EXTERNAL_BIT    = 1 << HWC_DISPLAY_EXTERNAL,
    HWC_DISPLAY_VIRTUAL_BIT     = 1 << HWC_DISPLAY_VIRTUAL,
};

struct lut_data{
    uint16_t size;
    uint16_t lred[LUT_SIZE];
    uint16_t lgreen[LUT_SIZE];
    uint16_t lblue[LUT_SIZE];
};

struct drm_display_mode {
    /* Proposed mode values */
    int clock;		/* in kHz */
    int hdisplay;
    int hsync_start;
    int hsync_end;
    int htotal;
    int vdisplay;
    int vsync_start;
    int vsync_end;
    int vtotal;
    int vrefresh;
    int vscan;
    unsigned int flags;
    int picture_aspect_ratio;
};

enum output_format {
    output_rgb=0,
    output_ycbcr444=1,
    output_ycbcr422=2,
    output_ycbcr420=3,
    output_ycbcr_high_subsampling=4,  // (YCbCr444 > YCbCr422 > YCbCr420 > RGB)
    output_ycbcr_low_subsampling=5	, // (RGB > YCbCr420 > YCbCr422 > YCbCr444)
    invalid_output=6,
};

enum output_depth {
    Automatic=0,
    depth_24bit=8,
    depth_30bit=10,
};

struct overscan {
    unsigned int maxvalue;
    unsigned short leftscale;
    unsigned short rightscale;
    unsigned short topscale;
    unsigned short bottomscale;
};

struct hwc_inital_info{
    char device[128];
    unsigned int framebuffer_width;
    unsigned int framebuffer_height;
    float fps;
};
struct bcsh_info {
    unsigned short brightness;
    unsigned short contrast;
    unsigned short saturation;
    unsigned short hue;
};

struct screen_info {
    int type;
    struct drm_display_mode resolution;// 52 bytes
    enum output_format  format; // 4 bytes
    enum output_depth depthc; // 4 bytes
    unsigned int feature;//4 //4 bytes
};

struct disp_info{
    struct screen_info screen_list[5];
    struct overscan scan;//12 bytes
    struct hwc_inital_info hwc_info; //140 bytes
    struct bcsh_info bcsh;
    unsigned int reserve[128]; //459x4
    struct lut_data mlutdata;/*6k+4*/
};


struct file_base_paramer
{
    struct disp_info main;
    struct disp_info aux;
};

static char const *const device_template[] =
{
    "/dev/block/platform/1021c000.rksdmmc/by-name/baseparameter",
    "/dev/block/platform/30020000.rksdmmc/by-name/baseparameter",
    "/dev/block/platform/ff0f0000.rksdmmc/by-name/baseparameter",
    "/dev/block/platform/ff520000.rksdmmc/by-name/baseparameter",
    "/dev/block/platform/fe330000.sdhci/by-name/baseparameter",
    "/dev/block/platform/ff520000.dwmmc/by-name/baseparameter",
    "/dev/block/platform/ff0f0000.dwmmc/by-name/baseparameter",
    "/dev/block/platform/ff390000.dwmmc/by-name/baseparameter",
    "/dev/block/rknand_baseparameter",
    NULL
};

const char* GetBaseparameterFile(void)
{
	LOGD("GetBaseparameterFile");
    int i = 0;
    while (device_template[i]) {
        if (!access(device_template[i], R_OK | W_OK))
            return device_template[i];
        LOGD("temp[%d]=%s access=%d(%s)", i,device_template[i], errno, strerror(errno));
        i++;
    }
    return NULL;
}

static int outputImage(const char *file_path, struct file_base_paramer *base, struct file_base_paramer *back){
	int fd;
	ssize_t ret;

	fd = open(file_path, O_CREAT | O_WRONLY, 0666);
	if (fd < 0) {
		LOGD("%s fail to open",file_path);
		return -1;
	}

	lseek(fd, BASEPARAMETER_IMAGE_SIZE-1, SEEK_SET);
	ret = write(fd, "\0", 1);
	if (ret < 0) {
		LOGD("end fail to write");
		goto out;
	}

	lseek(fd, 0L, SEEK_SET);
	ret = write(fd, (char*)(&base->main), sizeof(base->main));
	if (ret < 0) {
		LOGD("base->main fail to write");
		goto out;
	}
	lseek(fd, BASE_OFFSET, SEEK_SET);
	ret = write(fd, (char*)(&base->aux), sizeof(base->aux));
	if (ret < 0) {
		LOGD("base->aux fail to write");
		goto out;
	}

	lseek(fd, BACKUP_OFFSET, SEEK_SET);
	ret = write(fd, (char*)(&back->main), sizeof(back->main));
	if (ret < 0) {
		LOGD("back->main fail to write");
		goto out;
	}
	lseek(fd, BACKUP_OFFSET+BASE_OFFSET, SEEK_SET);
	ret = write(fd, (char*)(&back->aux), sizeof(back->aux));
	if (ret < 0) {
		LOGD("back->aux fail to write");
		goto out;
	}

	fsync(fd);
	close(fd);
	LOGD("create %s success\n", file_path);
	return 0;

	out:
		close(fd);
		return -1;
}


JNIEXPORT jint JNICALL Java_com_rockchip_graphics_SaveBaseParameterUtil_outputImage
  (JNIEnv * env, jclass clazz, jstring path, jint screen_no, jint size, jintArray red, jintArray green, jintArray blue)
  {
  	struct file_base_paramer base_paramer;
    struct file_base_paramer backup_paramer;
  	int file;
  	const char *target_save_file = env->GetStringUTFChars(path, NULL);
    const char *baseparameterfile = GetBaseparameterFile();

    if (!baseparameterfile) {
        sync();
        return -1;
    }

    file = open(baseparameterfile, O_RDWR);
    if (file < 0) {
        LOGD("base paramter file can not be opened \n");
        sync();
        return -1;
    }
    // caculate file's size and read it
    unsigned int length = lseek(file, 0L, SEEK_END);
    if(length < sizeof(base_paramer)) {
        LOGD("BASEPARAME data's length is error\n");
        close(file);
        return -1;
    }
    lseek(file, 0L, SEEK_SET);
    read(file, (void*)&(base_paramer.main), sizeof(base_paramer.main));/*read main display info*/
    lseek(file, BASE_OFFSET, SEEK_SET);
    read(file, (void*)&(base_paramer.aux), sizeof(base_paramer.aux));/*read aux display info*/
    lseek(file, BACKUP_OFFSET, SEEK_SET);
    read(file, (void*)&(backup_paramer.main), sizeof(backup_paramer.main));/*read main display info*/
    lseek(file, BACKUP_OFFSET + BASE_OFFSET, SEEK_SET);
    read(file, (void*)&(backup_paramer.aux), sizeof(backup_paramer.aux));/*read aux display info*/

    jsize jrsize = env->GetArrayLength(red);
    jsize jgsize = env->GetArrayLength(green);
    jsize jbsize = env->GetArrayLength(blue);

    jint* jr_data = env->GetIntArrayElements(red, /* isCopy */ NULL);
    jint* jg_data = env->GetIntArrayElements(green, /* isCopy */ NULL);
    jint* jb_data = env->GetIntArrayElements(blue, /* isCopy */ NULL);

    uint16_t* r = (uint16_t*)malloc(jrsize*sizeof(uint16_t));
    uint16_t* g = (uint16_t*)malloc(jgsize*sizeof(uint16_t));
    uint16_t* b = (uint16_t*)malloc(jbsize*sizeof(uint16_t));
    LOGD("jrsize %d",jrsize);
    for (int i=0;i<jrsize;i++) {
        r[i] = jr_data[i];
    }
    for (int i=0;i<jgsize;i++) {
        g[i] = jg_data[i];
    }
    for (int i=0;i<jbsize;i++) {
        b[i] = jb_data[i];
    }

    if(screen_no == 0){
        LOGD("set base_paramer.main \n");
        base_paramer.main.mlutdata.size = size;
        memcpy(base_paramer.main.mlutdata.lred, r, jrsize*sizeof(uint16_t));
        memcpy(base_paramer.main.mlutdata.lgreen, g, jrsize*sizeof(uint16_t));
        memcpy(base_paramer.main.mlutdata.lblue, b, jrsize*sizeof(uint16_t));
    }else if(screen_no == 1){
        LOGD("set base_paramer.aux \n");
        base_paramer.aux.mlutdata.size = size;
        memcpy(base_paramer.aux.mlutdata.lred, r, jrsize*sizeof(uint16_t));
        memcpy(base_paramer.aux.mlutdata.lgreen, g, jrsize*sizeof(uint16_t));
        memcpy(base_paramer.aux.mlutdata.lblue, b, jrsize*sizeof(uint16_t));
    }
    if (r)
        free(r);
    if (g)
        free(g);
    if (b)
        free(b);
    env->ReleaseIntArrayElements(red, jr_data, 0);
    env->ReleaseIntArrayElements(green, jg_data, 0);
    env->ReleaseIntArrayElements(blue, jb_data, 0);

    LOGD("start writing to %s\n", target_save_file);
    int ret = outputImage(target_save_file, &base_paramer, &backup_paramer);
    LOGD("writing to %s done, result:%d\n", target_save_file, ret);
    return 0;
  }

