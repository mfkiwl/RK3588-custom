package com.rockchip.graphics;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
//import android.os.SystemProperties;

public class BootFinishReceiver extends BroadcastReceiver {

    public static String DEVICE_LUMINANCE_PROPERTY = "sys.gdsp_lut.luminance";
    public static String DEVICE_CONTRAST_PROPERTY = "sys.gdsp_lut.contrast";

    @Override
    public void onReceive(Context context, Intent intent) {
        //Log.d(LineChartView.TAG, "zengfei on Receive boot finished ");
//		try {
//			String data = "";
//			FileWriter fw = new FileWriter(
//					com.rockchip.graphics.AdjustColorCompute.fileToWrite);
//			FileReader fb = new FileReader(
//					com.rockchip.graphics.AdjustColorCompute.fileToBkp);
//			BufferedReader br = new BufferedReader(fb);
//			data = br.readLine();
//			fw.write(data);
//			//Log.d("zengfei", data);
//			fw.close();
//			fb.close();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		restorePref(context);
        /*
		 * Intent i = new Intent(context, AutoConfigService.class);
		 * i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startService(i);
		 */
    }

    private void restorePref(Context context) {
        // get property set about luminance and contrast .
		/*
		 * String s_luminance = SystemProperties.get(DEVICE_LUMINANCE_PROPERTY,
		 * "10"); String s_contrast =
		 * SystemProperties.get(DEVICE_CONTRAST_PROPERTY, "10");
		 * Log.d(LineChartView.TAG,
		 * " system getproperty from device luminance  " + s_luminance +
		 * " contrast " + s_contrast);
		 * 
		 * Integer l = new Integer(s_luminance); Integer c = new
		 * Integer(s_contrast);
		 * 
		 * SharedPreferences sp =
		 * context.getSharedPreferences(BizLineAdjustActivity
		 * .sSharedPreferencesKey, Context.MODE_PRIVATE); int restoreLight =
		 * sp.getInt(BizLineAdjustActivity.DB_LIGHT_VALUE, l.intValue()); int
		 * restoreContrast = sp.getInt(BizLineAdjustActivity.DB_CONTRAST_VALUE,
		 * c.intValue());
		 * 
		 * AdjustColorCompute computeUtil = new AdjustColorCompute();
		 * computeUtil.computeLUTData(restoreLight, restoreContrast );
		 * computeUtil.writeToFile(); Log.d(LineChartView.TAG, "default_light "
		 * + restoreLight + " contrast " + restoreContrast);
		 */

    }

}
