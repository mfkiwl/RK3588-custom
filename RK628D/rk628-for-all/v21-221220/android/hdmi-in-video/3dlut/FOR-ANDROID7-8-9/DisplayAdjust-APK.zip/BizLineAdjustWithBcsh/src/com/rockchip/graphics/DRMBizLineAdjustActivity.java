package com.rockchip.graphics;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.RkDisplayOutputManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;

public class DRMBizLineAdjustActivity extends Activity implements
        SeekBar.OnSeekBarChangeListener, View.OnClickListener {

    private static final int MAIN_SCREEN = 0;
    private static final int AUX_SCREEN = 1;
    private static final int DRM_MODE_CONNECTED = 1;
    private static final int DRM_MODE_DISCONNECTED = 2;
    private static final int DRM_MODE_UNKNOWNCONNECTION = 3;
    private static final int DRM_MODE_CONNECTOR_LVDS = 7;
    private static final int DRM_MODE_CONNECTOR_eDP = 14;
	private static final int DRM_MODE_CONNECTOR_DSI = 16;
    private static final int DEFAULT_COLOR_TEMPERATURE = 2;
    private static final String TAG = "DRMBizLineAdjustActivity";
    private static final String SELECT_COLOR_TEMPERATURE_PROPERTY = "persist.sys.color.temperature";
    private static final String OUTPUT_IMAGE_PATH = "/sdcard/baseparameter.img";
    private static final boolean DEBUG = true;
    private static final int LUT_SIZE = 1024;
    private static final int[] COLOR_TEMPERATURE_VALUE = {
            3500, 5500, 6500, 7500
    };

    private double blackbody_color[] = {
            1.00000000,  0.18172716,  0.00000000, /* 1000K */
            1.00000000,  0.25503671,  0.00000000, /* 1100K */
            1.00000000,  0.30942099,  0.00000000, /* 1200K */
            1.00000000,  0.35357379,  0.00000000, /* ...   */
            1.00000000,  0.39091524,  0.00000000,
            1.00000000,  0.42322816,  0.00000000,
            1.00000000,  0.45159884,  0.00000000,
            1.00000000,  0.47675916,  0.00000000,
            1.00000000,  0.49923747,  0.00000000,
            1.00000000,  0.51943421,  0.00000000,
            1.00000000,  0.54360078,  0.08679949,
            1.00000000,  0.56618736,  0.14065513,
            1.00000000,  0.58734976,  0.18362641,
            1.00000000,  0.60724493,  0.22137978,
            1.00000000,  0.62600248,  0.25591950,
            1.00000000,  0.64373109,  0.28819679,
            1.00000000,  0.66052319,  0.31873863,
            1.00000000,  0.67645822,  0.34786758,
            1.00000000,  0.69160518,  0.37579588,
            1.00000000,  0.70602449,  0.40267128,
            1.00000000,  0.71976951,  0.42860152,
            1.00000000,  0.73288760,  0.45366838,
            1.00000000,  0.74542112,  0.47793608,
            1.00000000,  0.75740814,  0.50145662,
            1.00000000,  0.76888303,  0.52427322,
            1.00000000,  0.77987699,  0.54642268,
            1.00000000,  0.79041843,  0.56793692,
            1.00000000,  0.80053332,  0.58884417,
            1.00000000,  0.81024551,  0.60916971,
            1.00000000,  0.81957693,  0.62893653,
            1.00000000,  0.82854786,  0.64816570,
            1.00000000,  0.83717703,  0.66687674,
            1.00000000,  0.84548188,  0.68508786,
            1.00000000,  0.85347859,  0.70281616,
            1.00000000,  0.86118227,  0.72007777,
            1.00000000,  0.86860704,  0.73688797,
            1.00000000,  0.87576611,  0.75326132,
            1.00000000,  0.88267187,  0.76921169,
            1.00000000,  0.88933596,  0.78475236,
            1.00000000,  0.89576933,  0.79989606,
            1.00000000,  0.90198230,  0.81465502,
            1.00000000,  0.90963069,  0.82838210,
            1.00000000,  0.91710889,  0.84190889,
            1.00000000,  0.92441842,  0.85523742,
            1.00000000,  0.93156127,  0.86836903,
            1.00000000,  0.93853986,  0.88130458,
            1.00000000,  0.94535695,  0.89404470,
            1.00000000,  0.95201559,  0.90658983,
            1.00000000,  0.95851906,  0.91894041,
            1.00000000,  0.96487079,  0.93109690,
            1.00000000,  0.97107439,  0.94305985,
            1.00000000,  0.97713351,  0.95482993,
            1.00000000,  0.98305189,  0.96640795,
            1.00000000,  0.98883326,  0.97779486,
            1.00000000,  0.99448139,  0.98899179,
            1.00000000,  1.00000000,  1.00000000, /* 6500K */
            0.98947904,  0.99348723,  1.00000000,
            0.97940448,  0.98722715,  1.00000000,
            0.96975025,  0.98120637,  1.00000000,
            0.96049223,  0.97541240,  1.00000000,
            0.95160805,  0.96983355,  1.00000000,
            0.94303638,  0.96443333,  1.00000000,
            0.93480451,  0.95923080,  1.00000000,
            0.92689056,  0.95421394,  1.00000000,
            0.91927697,  0.94937330,  1.00000000,
            0.91194747,  0.94470005,  1.00000000,
            0.90488690,  0.94018594,  1.00000000,
            0.89808115,  0.93582323,  1.00000000,
            0.89151710,  0.93160469,  1.00000000,
            0.88518247,  0.92752354,  1.00000000,
            0.87906581,  0.92357340,  1.00000000,
            0.87315640,  0.91974827,  1.00000000,
            0.86744421,  0.91604254,  1.00000000,
            0.86191983,  0.91245088,  1.00000000,
            0.85657444,  0.90896831,  1.00000000,
            0.85139976,  0.90559011,  1.00000000,
            0.84638799,  0.90231183,  1.00000000,
            0.84153180,  0.89912926,  1.00000000,
            0.83682430,  0.89603843,  1.00000000,
            0.83225897,  0.89303558,  1.00000000,
            0.82782969,  0.89011714,  1.00000000,
            0.82353066,  0.88727974,  1.00000000,
            0.81935641,  0.88452017,  1.00000000,
            0.81530175,  0.88183541,  1.00000000,
            0.81136180,  0.87922257,  1.00000000,
            0.80753191,  0.87667891,  1.00000000,
            0.80380769,  0.87420182,  1.00000000,
            0.80018497,  0.87178882,  1.00000000,
            0.79665980,  0.86943756,  1.00000000,
            0.79322843,  0.86714579,  1.00000000,
            0.78988728,  0.86491137,  1.00000000, /* 10000K */
            0.78663296,  0.86273225,  1.00000000,
            0.78346225,  0.86060650,  1.00000000,
            0.78037207,  0.85853224,  1.00000000,
            0.77735950,  0.85650771,  1.00000000,
            0.77442176,  0.85453121,  1.00000000,
            0.77155617,  0.85260112,  1.00000000,
            0.76876022,  0.85071588,  1.00000000,
            0.76603147,  0.84887402,  1.00000000,
            0.76336762,  0.84707411,  1.00000000,
            0.76076645,  0.84531479,  1.00000000,
            0.75822586,  0.84359476,  1.00000000,
            0.75574383,  0.84191277,  1.00000000,
            0.75331843,  0.84026762,  1.00000000,
            0.75094780,  0.83865816,  1.00000000,
            0.74863017,  0.83708329,  1.00000000,
            0.74636386,  0.83554194,  1.00000000,
            0.74414722,  0.83403311,  1.00000000,
            0.74197871,  0.83255582,  1.00000000,
            0.73985682,  0.83110912,  1.00000000,
            0.73778012,  0.82969211,  1.00000000,
            0.73574723,  0.82830393,  1.00000000,
            0.73375683,  0.82694373,  1.00000000,
            0.73180765,  0.82561071,  1.00000000,
            0.72989845,  0.82430410,  1.00000000,
            0.72802807,  0.82302316,  1.00000000,
            0.72619537,  0.82176715,  1.00000000,
            0.72439927,  0.82053539,  1.00000000,
            0.72263872,  0.81932722,  1.00000000,
            0.72091270,  0.81814197,  1.00000000,
            0.71922025,  0.81697905,  1.00000000,
            0.71756043,  0.81583783,  1.00000000,
            0.71593234,  0.81471775,  1.00000000,
            0.71433510,  0.81361825,  1.00000000,
            0.71276788,  0.81253878,  1.00000000,
            0.71122987,  0.81147883,  1.00000000,
            0.70972029,  0.81043789,  1.00000000,
            0.70823838,  0.80941546,  1.00000000,
            0.70678342,  0.80841109,  1.00000000,
            0.70535469,  0.80742432,  1.00000000,
            0.70395153,  0.80645469,  1.00000000,
            0.70257327,  0.80550180,  1.00000000,
            0.70121928,  0.80456522,  1.00000000,
            0.69988894,  0.80364455,  1.00000000,
            0.69858167,  0.80273941,  1.00000000,
            0.69729688,  0.80184943,  1.00000000,
            0.69603402,  0.80097423,  1.00000000,
            0.69479255,  0.80011347,  1.00000000,
            0.69357196,  0.79926681,  1.00000000,
            0.69237173,  0.79843391,  1.00000000,
            0.69119138,  0.79761446,  1.00000000, /* 15000K */
            0.69003044,  0.79680814,  1.00000000,
            0.68888844,  0.79601466,  1.00000000,
            0.68776494,  0.79523371,  1.00000000,
            0.68665951,  0.79446502,  1.00000000,
            0.68557173,  0.79370830,  1.00000000,
            0.68450119,  0.79296330,  1.00000000,
            0.68344751,  0.79222975,  1.00000000,
            0.68241029,  0.79150740,  1.00000000,
            0.68138918,  0.79079600,  1.00000000,
            0.68038380,  0.79009531,  1.00000000,
            0.67939381,  0.78940511,  1.00000000,
            0.67841888,  0.78872517,  1.00000000,
            0.67745866,  0.78805526,  1.00000000,
            0.67651284,  0.78739518,  1.00000000,
            0.67558112,  0.78674472,  1.00000000,
            0.67466317,  0.78610368,  1.00000000,
            0.67375872,  0.78547186,  1.00000000,
            0.67286748,  0.78484907,  1.00000000,
            0.67198916,  0.78423512,  1.00000000,
            0.67112350,  0.78362984,  1.00000000,
            0.67027024,  0.78303305,  1.00000000,
            0.66942911,  0.78244457,  1.00000000,
            0.66859988,  0.78186425,  1.00000000,
            0.66778228,  0.78129191,  1.00000000,
            0.66697610,  0.78072740,  1.00000000,
            0.66618110,  0.78017057,  1.00000000,
            0.66539706,  0.77962127,  1.00000000,
            0.66462376,  0.77907934,  1.00000000,
            0.66386098,  0.77854465,  1.00000000,
            0.66310852,  0.77801705,  1.00000000,
            0.66236618,  0.77749642,  1.00000000,
            0.66163375,  0.77698261,  1.00000000,
            0.66091106,  0.77647551,  1.00000000,
            0.66019791,  0.77597498,  1.00000000,
            0.65949412,  0.77548090,  1.00000000,
            0.65879952,  0.77499315,  1.00000000,
            0.65811392,  0.77451161,  1.00000000,
            0.65743716,  0.77403618,  1.00000000,
            0.65676908,  0.77356673,  1.00000000,
            0.65610952,  0.77310316,  1.00000000,
            0.65545831,  0.77264537,  1.00000000,
            0.65481530,  0.77219324,  1.00000000,
            0.65418036,  0.77174669,  1.00000000,
            0.65355332,  0.77130560,  1.00000000,
            0.65293404,  0.77086988,  1.00000000,
            0.65232240,  0.77043944,  1.00000000,
            0.65171824,  0.77001419,  1.00000000,
            0.65112144,  0.76959404,  1.00000000,
            0.65053187,  0.76917889,  1.00000000,
            0.64994941,  0.76876866,  1.00000000, /* 20000K */
            0.64937392,  0.76836326,  1.00000000,
            0.64880528,  0.76796263,  1.00000000,
            0.64824339,  0.76756666,  1.00000000,
            0.64768812,  0.76717529,  1.00000000,
            0.64713935,  0.76678844,  1.00000000,
            0.64659699,  0.76640603,  1.00000000,
            0.64606092,  0.76602798,  1.00000000,
            0.64553103,  0.76565424,  1.00000000,
            0.64500722,  0.76528472,  1.00000000,
            0.64448939,  0.76491935,  1.00000000,
            0.64397745,  0.76455808,  1.00000000,
            0.64347129,  0.76420082,  1.00000000,
            0.64297081,  0.76384753,  1.00000000,
            0.64247594,  0.76349813,  1.00000000,
            0.64198657,  0.76315256,  1.00000000,
            0.64150261,  0.76281076,  1.00000000,
            0.64102399,  0.76247267,  1.00000000,
            0.64055061,  0.76213824,  1.00000000,
            0.64008239,  0.76180740,  1.00000000,
            0.63961926,  0.76148010,  1.00000000,
            0.63916112,  0.76115628,  1.00000000,
            0.63870790,  0.76083590,  1.00000000,
            0.63825953,  0.76051890,  1.00000000,
            0.63781592,  0.76020522,  1.00000000,
            0.63737701,  0.75989482,  1.00000000,
            0.63694273,  0.75958764,  1.00000000,
            0.63651299,  0.75928365,  1.00000000,
            0.63608774,  0.75898278,  1.00000000,
            0.63566691,  0.75868499,  1.00000000,
            0.63525042,  0.75839025,  1.00000000,
            0.63483822,  0.75809849,  1.00000000,
            0.63443023,  0.75780969,  1.00000000,
            0.63402641,  0.75752379,  1.00000000,
            0.63362667,  0.75724075,  1.00000000,
            0.63323097,  0.75696053,  1.00000000,
            0.63283925,  0.75668310,  1.00000000,
            0.63245144,  0.75640840,  1.00000000,
            0.63206749,  0.75613641,  1.00000000,
            0.63168735,  0.75586707,  1.00000000,
            0.63131096,  0.75560036,  1.00000000,
            0.63093826,  0.75533624,  1.00000000,
            0.63056920,  0.75507467,  1.00000000,
            0.63020374,  0.75481562,  1.00000000,
            0.62984181,  0.75455904,  1.00000000,
            0.62948337,  0.75430491,  1.00000000,
            0.62912838,  0.75405319,  1.00000000,
            0.62877678,  0.75380385,  1.00000000,
            0.62842852,  0.75355685,  1.00000000,
            0.62808356,  0.75331217,  1.00000000,
            0.62774186,  0.75306977,  1.00000000, /* 25000K */
            0.62740336,  0.75282962,  1.00000000  /* 25100K */
    };
    private double[] white_point = new double[3];
    private double F(double Y,int C){
        return (Math.pow( Y * white_point[C], 1.0 / 1));
    }
    private View mLayout_chart_panel;
    private View mLayout_saturation;
    private View mLayout_hue;
    private View mLayout_bcsh;
    private SeekBar mSeekBar_bright;
    private SeekBar mSeekBar_contrast;
    private SeekBar mSeekBar_saturation;
    private SeekBar mSeekBar_hue;
    private SeekBar mSeekBar_color_temperature;
    private TextView mText_bright;
    private TextView mText_contrast;
    private TextView mText_saturation;
    private TextView mText_hue;
    private TextView mText_bcsh;
    private TextView mText_color_temperature;

    private final int DEFAULT_VALUE = 50;
    private final int DEFAULT_MAX_VALUE = 100;
    private int mLight = DEFAULT_VALUE;
    private int mContrast = DEFAULT_VALUE;
    private int mSaturation = DEFAULT_VALUE;
    private int mHue = DEFAULT_VALUE;
    private int mCurScreen = MAIN_SCREEN;
    private int mColorTemperature = DEFAULT_COLOR_TEMPERATURE;
    private Bitmap mCurrentBitmap;
    private Object mLock = new Object();
    private RkDisplayOutputManager mRkDisplayOutputManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.vop_display_adjust);
        log("onCreate");
        mRkDisplayOutputManager = new RkDisplayOutputManager();
        initUI();
        initValue();
        initListener();
//        synchronized (mLock) {
//            initValue();
//            resetValuesDirect();
//        }
    }

    private void initUI() {
        mLayout_chart_panel = findViewById(R.id.chart_panel);
        mLayout_saturation = findViewById(R.id.layout_saturation);
        mLayout_hue = findViewById(R.id.layout_hue);
        mLayout_bcsh = findViewById(R.id.layout_bcsh);
        mSeekBar_bright = (SeekBar) findViewById(R.id.seekBar_bright);
        mSeekBar_contrast = (SeekBar) findViewById(R.id.seekBar_contrast);
        mSeekBar_saturation = (SeekBar) findViewById(R.id.seekBar_saturation);
        mSeekBar_hue = (SeekBar) findViewById(R.id.seekBar_hue);
        mSeekBar_color_temperature = (SeekBar) findViewById(R.id.seekBar_color_temperature);
        mText_bright = (TextView) findViewById(R.id.bright_tile);
        mText_contrast = (TextView) findViewById(R.id.contrast_tile);
        mText_saturation = (TextView) findViewById(R.id.saturation_title);
        mText_hue = (TextView) findViewById(R.id.hue_tile);
        mText_bcsh = (TextView) findViewById(R.id.bcsh_tile);
        mText_color_temperature = (TextView) findViewById(R.id.color_temperature_title);

        mLayout_chart_panel.setVisibility(View.GONE);
        mText_saturation.setVisibility(View.VISIBLE);
        mLayout_saturation.setVisibility(View.VISIBLE);
        mText_hue.setVisibility(View.VISIBLE);
        mLayout_hue.setVisibility(View.VISIBLE);
        mText_bcsh.setVisibility(View.GONE);
        mLayout_bcsh.setVisibility(View.GONE);
    }

    private void initValue() {
        getBrightness();
        getContrast();
        getSaturation();
        getHue();
        getColorTemperature();
        log(String.format("mLight %d,mContrast %d,mSaturation %d,mHue %d colorTemperature %d", mLight, mContrast, mSaturation, mHue, COLOR_TEMPERATURE_VALUE[mColorTemperature]));

        mSeekBar_bright.setMax(DEFAULT_MAX_VALUE);
        mSeekBar_bright.setProgress(mLight);
        mSeekBar_contrast.setMax(DEFAULT_MAX_VALUE);
        mSeekBar_contrast.setProgress(mContrast);
        mSeekBar_saturation.setMax(DEFAULT_MAX_VALUE);
        mSeekBar_saturation.setProgress(mSaturation);
        mSeekBar_hue.setMax(DEFAULT_MAX_VALUE);
        mSeekBar_hue.setProgress(mHue);
        mSeekBar_color_temperature.setMax(COLOR_TEMPERATURE_VALUE.length - 1);
        mSeekBar_color_temperature.setProgress(mColorTemperature);

        textBrightShow();
        textContrastShow();
        textSaturationShow();
        textHueShow();
        textColorTemperatureShow();
    }

    private void initListener() {
        mSeekBar_bright.setOnSeekBarChangeListener(this);
        mSeekBar_contrast.setOnSeekBarChangeListener(this);
        mSeekBar_saturation.setOnSeekBarChangeListener(this);
        mSeekBar_hue.setOnSeekBarChangeListener(this);
        mSeekBar_color_temperature.setOnSeekBarChangeListener(this);
        findViewById(R.id.change_image).setOnClickListener(this);
        findViewById(R.id.reset_btn).setOnClickListener(this);
        findViewById(R.id.bri_del).setOnClickListener(this);
        findViewById(R.id.bri_add).setOnClickListener(this);
        findViewById(R.id.con_del).setOnClickListener(this);
        findViewById(R.id.con_add).setOnClickListener(this);
        findViewById(R.id.saturation_del).setOnClickListener(this);
        findViewById(R.id.saturation_add).setOnClickListener(this);
        findViewById(R.id.hue_del).setOnClickListener(this);
        findViewById(R.id.hue_add).setOnClickListener(this);
        findViewById(R.id.color_temperature_del).setOnClickListener(this);
        findViewById(R.id.color_temperature_add).setOnClickListener(this);
        findViewById(R.id.output_btn).setOnClickListener(this);
    }

    private void removeListener() {
        mSeekBar_bright.setOnSeekBarChangeListener(null);
        mSeekBar_contrast.setOnSeekBarChangeListener(null);
        mSeekBar_saturation.setOnSeekBarChangeListener(null);
        mSeekBar_hue.setOnSeekBarChangeListener(null);
    }

    private void textBrightShow() {
        mText_bright.setText(getString(R.string.bright_label) + " val = " + mLight);
    }

    private void textContrastShow() {
        mText_contrast.setText(getString(R.string.contrast_label) + " val = " + mContrast);
    }

    private void textSaturationShow() {
        mText_saturation.setText(getString(R.string.saturation_label) + " val = " + mSaturation);
    }

    private void textHueShow() {
        mText_hue.setText(getString(R.string.hue_label) + " val = " + mHue);
    }

    private void resetProgress() {
        mSeekBar_bright.setProgress(DEFAULT_VALUE);
        mSeekBar_contrast.setProgress(DEFAULT_VALUE);
        mSeekBar_saturation.setProgress(DEFAULT_VALUE);
        mSeekBar_hue.setProgress(DEFAULT_VALUE);
        mSeekBar_color_temperature.setProgress(DEFAULT_COLOR_TEMPERATURE);
    }

    private void resetValuesDirect() {
        synchronized (mLock) {
//            removeListener();
            mLight = DEFAULT_VALUE;
            mContrast = DEFAULT_VALUE;
            mSaturation = DEFAULT_VALUE;
            mHue = DEFAULT_VALUE;
            mColorTemperature = DEFAULT_COLOR_TEMPERATURE;
            resetProgress();
//            setBrightProp();
            setBrightness();
            textBrightShow();
//            setContrastProp();
            setContrast();
            textContrastShow();
//            setSaturationProp();
            setContrast();
            textSaturationShow();
//            setHueProp();
            setHue();
            textHueShow();
            setColorTemperature(COLOR_TEMPERATURE_VALUE[mColorTemperature]);
            textColorTemperatureShow();
//            setTimeLineProp();
//            initListener();
        }
    }

    private void setBrightProp() {
        SystemProperties.set("persist.sys.brightness.main", String.valueOf(mLight));
    }

    private void setContrastProp() {
        SystemProperties.set("persist.sys.contrast.main", String.valueOf(mContrast));
    }

    private void setSaturationProp() {
        SystemProperties.set("persist.sys.saturation.main", String.valueOf(mSaturation));
    }

    private void setHueProp() {
        SystemProperties.set("persist.sys.hue.main", String.valueOf(mHue));
    }

    private void setTimeLineProp() {
        String strValue = SystemProperties.get("sys.display.timeline");
        Integer value = 0;
        try {
            value = Integer.parseInt(strValue);
        } catch (NumberFormatException e) {

        }
        SystemProperties.set("sys.display.timeline", String.valueOf(++value));
    }

    private int setBrightness() {
        int ret = mRkDisplayOutputManager.setBrightness(mCurScreen, mLight);
        if (ret == 0) {
            mRkDisplayOutputManager.saveConfig();
        }
        return ret;
    }

    private int setContrast() {
        int ret = mRkDisplayOutputManager.setContrast(mCurScreen, mContrast);
        if (ret == 0) {
            mRkDisplayOutputManager.saveConfig();
        }
        return ret;
    }

    private int setSaturation() {
        int ret = mRkDisplayOutputManager.setSaturation(mCurScreen, mSaturation);
        if (ret == 0) {
            mRkDisplayOutputManager.saveConfig();
        }
        return ret;
    }

    private int setHue() {
        int ret = mRkDisplayOutputManager.setHue(mCurScreen, mHue);
        if (ret == 0) {
            mRkDisplayOutputManager.saveConfig();
        }
        return ret;
    }

    private void log(String msg) {
        if (DEBUG) {
            Log.d(TAG, msg);
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromTouch) {
        switch (seekBar.getId()) {
            case R.id.seekBar_bright:
                    mLight = progress;
                    textBrightShow();
//                  setBrightProp();
                    setBrightness();
//                  setTimeLineProp();
                break;
            case R.id.seekBar_contrast:
                    mContrast = progress;
                    textContrastShow();
//                  setContrastProp();
                    setContrast();
//                  setTimeLineProp();
                break;
            case R.id.seekBar_saturation:
                    mSaturation = progress;
                    textSaturationShow();
//                  setSaturationProp();
                    setSaturation();
//                  setTimeLineProp();
                break;
            case R.id.seekBar_hue:
                    mHue = progress;
                    textHueShow();
//                  setHueProp();
                    setHue();
//                  setTimeLineProp();
                break;
            case R.id.seekBar_color_temperature:
                mColorTemperature = progress;
                textColorTemperatureShow();
                setColorTemperature(COLOR_TEMPERATURE_VALUE[mColorTemperature]);
                break;
            default:
                break;
        }
        log(String.format("mLight %d,mContrast %d,mSaturation %d,mHue %d colorTemperature %d", mLight, mContrast, mSaturation, mHue, COLOR_TEMPERATURE_VALUE[mColorTemperature]));
    }

    @Override
    protected void onDestroy() {
        log("onDestroy");
//        resetProgress();
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        if (resultCode == RESULT_OK) {
            Uri uri = data.getData();
            log("uri " + uri.toString());
            ContentResolver cr = this.getContentResolver();
            if (mCurrentBitmap != null) {
                mCurrentBitmap.recycle();
                mCurrentBitmap = null;
            }
            try {
                mCurrentBitmap = BitmapFactory.decodeStream(cr
                        .openInputStream(uri));
                ImageView imageView = (ImageView) findViewById(R.id.image_view);
                /* 将Bitmap设定到ImageView */
                imageView.setBackgroundDrawable(new BitmapDrawable(
                        mCurrentBitmap));
            } catch (FileNotFoundException e) {
                Log.e("Exception", e.getMessage(), e);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.change_image: {
                Intent intent = new Intent();
                /* Open the page of select pictures and set the type to image */
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, BizLineAdjustActivity.REQ_CODE_PICTURES);
                break;
            }
            case R.id.reset_btn: {
                resetProgress();
                break;
            }
            case R.id.bri_del: {
                if (mLight > 0) {
                    mLight--;
                    textBrightShow();
                    mSeekBar_bright.setProgress(mLight);
                }
                break;
            }
            case R.id.bri_add: {
                if (mLight < DEFAULT_MAX_VALUE) {
                    mLight++;
                    textBrightShow();
                    mSeekBar_bright.setProgress(mLight);
                }
                break;
            }
            case R.id.con_del: {
                if (mContrast > 0) {
                    mContrast--;
                    textContrastShow();
                    mSeekBar_contrast.setProgress(mContrast);
                }
                break;
            }
            case R.id.con_add: {
                if (mContrast < DEFAULT_MAX_VALUE) {
                    mContrast++;
                    textContrastShow();
                    mSeekBar_contrast.setProgress(mContrast);
                }
                break;
            }
            case R.id.saturation_del: {
                if (mSaturation > 0) {
                    mSaturation--;
                    textSaturationShow();
                    mSeekBar_saturation.setProgress(mSaturation);
                }
                break;
            }
            case R.id.saturation_add: {
                if (mSaturation < DEFAULT_MAX_VALUE) {
                    mSaturation++;
                    textSaturationShow();
                    mSeekBar_saturation.setProgress(mSaturation);
                }
                break;
            }
            case R.id.hue_del: {
                if (mHue > 0) {
                    mHue--;
                    textHueShow();
                    mSeekBar_hue.setProgress(mHue);
                }
                break;
            }
            case R.id.hue_add: {
                if (mHue < DEFAULT_MAX_VALUE) {
                    mHue++;
                    textHueShow();
                    mSeekBar_hue.setProgress(mHue);
                }
                break;
            }
            case R.id.color_temperature_add: {
                if (mColorTemperature < COLOR_TEMPERATURE_VALUE.length - 1) {
                    mColorTemperature++;
                    textColorTemperatureShow();
                    mSeekBar_color_temperature.setProgress(mColorTemperature);
                }
                break;
            }
            case R.id.color_temperature_del:{
                if (mColorTemperature > 0) {
                    mColorTemperature--;
                    textColorTemperatureShow();
                    mSeekBar_color_temperature.setProgress(mColorTemperature);
                }
                break;
            }
            case R.id.output_btn:{
                int[][] rgb = colorTemperatureToRGB(COLOR_TEMPERATURE_VALUE[mColorTemperature]);
                int ret = SaveBaseParameterUtil.outputImage(OUTPUT_IMAGE_PATH, mCurScreen, LUT_SIZE, rgb[0], rgb[1], rgb[2]);
                if (ret == 0) {
                    Toast.makeText(DRMBizLineAdjustActivity.this, R.string.output_success, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(DRMBizLineAdjustActivity.this, R.string.output_fail, Toast.LENGTH_SHORT).show();
                }
                break;
            }
        }
    }

    private int[][] colorTemperatureToRGB(int tmp){
        int[][] ret = new int[3][LUT_SIZE];
        int[] red = new int[LUT_SIZE];
        int[] green = new int[LUT_SIZE];
        int[] blue = new int[LUT_SIZE];

        double alpha = (tmp % 100 / 100.0);
        int temp_index = ((tmp - 1000) / 100) * 3;
        white_point[0] = ((1.0 - alpha) * blackbody_color[temp_index] + alpha * blackbody_color[temp_index + 3]);
        white_point[1] = ((1.0 - alpha) * blackbody_color[temp_index + 1] + alpha * blackbody_color[temp_index + 4]);
        white_point[2] = ((1.0 - alpha) * blackbody_color[temp_index + 2] + alpha * blackbody_color[temp_index + 5]);
        log("tmpVaule:" + tmp + ",Whit_Point:" + white_point[0] + "," + white_point[1] + "," + white_point[2]);

        for (int i = 0; i < LUT_SIZE; i++) {
            double temp = i * 65535 / (LUT_SIZE - 1);
            red[i] = (int) (F((double) (temp / 65536.0), 0) * 65536);
            green[i] = (int) (F((double) (temp / (65536.0)), 1) * 65536);
            blue[i] = (int) (F((double) (temp / (65536.0)), 2) * 65536);
        }
        ret[0] =  red;
        ret[1] =  green;
        ret[2] =  blue;
        return ret;
    }

    private void setColorTemperature(int tmp) {
        String currentTag = SystemProperties.get(SELECT_COLOR_TEMPERATURE_PROPERTY);
        String newTag = String.valueOf(tmp);
        log("currentTag is " + currentTag + " , newValue is " + newTag);
        if (currentTag == null) {
            currentTag = "6500";
        }
        if (currentTag == newTag) {
            return;
        }
        SystemProperties.set(SELECT_COLOR_TEMPERATURE_PROPERTY, newTag);
        Object rkDisplayOutputManager = null;
        int displayNumber;
        int currMainState = 0;
        int currExternalState = 0;
        int currMainType = 0;
        int currExternalType = 0;

        int[] red = new int[LUT_SIZE];
        int[] green = new int[LUT_SIZE];
        int[] blue = new int[LUT_SIZE];
        int[][] rgb = colorTemperatureToRGB(tmp);

        red = rgb[0];
        green = rgb[1];
        blue = rgb[2];

        displayNumber = mRkDisplayOutputManager.getDisplayNumber();
        currMainState = mRkDisplayOutputManager.getCurrentDpyConnState(MAIN_SCREEN);
        currMainType = mRkDisplayOutputManager.getCurrentInterface(MAIN_SCREEN);
        log("currMainState is " + currMainState + ",currMainType is " + currMainType);
        if (displayNumber > 1) {
            currExternalState = mRkDisplayOutputManager.getCurrentDpyConnState(AUX_SCREEN);
            currExternalType = mRkDisplayOutputManager.getCurrentInterface(AUX_SCREEN);
            log("currExternalState is " + currExternalState + ",currExternalType is " + currExternalType);
        }

        if (currMainState == DRM_MODE_CONNECTED && (currMainType == DRM_MODE_CONNECTOR_LVDS || currMainType == DRM_MODE_CONNECTOR_eDP || currMainType == DRM_MODE_CONNECTOR_DSI)) {
            mRkDisplayOutputManager.setGamma(MAIN_SCREEN, LUT_SIZE, red, green, blue);
            mRkDisplayOutputManager.saveConfig();
        }
        if (currExternalState == DRM_MODE_CONNECTED && (currExternalState == DRM_MODE_CONNECTOR_LVDS || currExternalType == DRM_MODE_CONNECTOR_eDP || currMainType == DRM_MODE_CONNECTOR_DSI)) {
            mRkDisplayOutputManager.setGamma(AUX_SCREEN, LUT_SIZE, red, green, blue);
            mRkDisplayOutputManager.saveConfig();
        }
    }

    public void getBrightness() {
        mLight = mRkDisplayOutputManager.getBrightness(mCurScreen);
    }

    public void getContrast() {
        mContrast = mRkDisplayOutputManager.getContrast(mCurScreen);
    }

    public void getSaturation() {
        mSaturation = mRkDisplayOutputManager.getSaturation(mCurScreen);
    }

    public void getHue() {
        mHue = mRkDisplayOutputManager.getHue(mCurScreen);
    }

    public void getColorTemperature() {
        /*int curTmp = 0;
        int rgb[] = mRkDisplayOutputManager.getGamma(mCurScreen);
        if (rgb.length == 1024 * 3) {
            curTmp = rgbToColorTemperature(rgb[1024 - 1], rgb[2 * 1024 - 1], rgb[3 * 1024 - 1]);
            log("getGamma color " + curTmp);
            if (!String.valueOf(curTmp).equals(SystemProperties.get(SELECT_COLOR_TEMPERATURE_PROPERTY))) {
                SystemProperties.set(SELECT_COLOR_TEMPERATURE_PROPERTY, String.valueOf(curTmp));
            }
        } else {
            try {
                curTmp = Integer.parseInt(SystemProperties.get(SELECT_COLOR_TEMPERATURE_PROPERTY));
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        for (int i = 0; curTmp != 0 && i < COLOR_TEMPERATURE_VALUE.length; i++) {
            if (curTmp == COLOR_TEMPERATURE_VALUE[i]) {
                mColorTemperature = i;
                return;
            }
        }*/
        mColorTemperature = DEFAULT_COLOR_TEMPERATURE;
    }

    private void textColorTemperatureShow() {
        mText_color_temperature.setText(getString(R.string.color_temperature_label) + " val = " + COLOR_TEMPERATURE_VALUE[mColorTemperature]);
    }

    private int rgbToColorTemperature(int r, int g, int b) {
        for (int i = 0; i < blackbody_color.length; i += 3) {
            if (format4DigitDecimal(blackbody_color[i]) == format4DigitDecimal((double) r / 65535)
                    && format4DigitDecimal(blackbody_color[i + 1]) == format4DigitDecimal((double) g / 65535)
                    && format4DigitDecimal(blackbody_color[i + 2]) == format4DigitDecimal((double) b / 65535)) {
                return (1000 + 100 * i / 3);
            }
        }
        return 6500;
    }

    private double format4DigitDecimal(double x) {
        return (double) (Math.round(x * 10000) / 10000.0);
    }
}
