package com.rockchip.graphics;

import java.io.FileNotFoundException;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
//import android.os.SystemProperties;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

public class BizLineAdjustActivity extends Activity implements
        SeekBar.OnSeekBarChangeListener {

    static final String sSharedPreferencesKey = "com.rockchip.graphics.prefs";
    static String DB_CONTRAST_VALUE = "db_contrast";
    static String DB_LIGHT_VALUE = "db_light";
    static String DB_BCSH_VALUE = "db_bcsh";

    SeekBar mSeekBar_bright;
    SeekBar mSeekBar_contrast;
    SeekBar mSeekBar_gamma;
    SeekBar mSeekBar_bcsh;
    TextView mText_bright;
    TextView mText_contrast;
    TextView mText_bcsh;
    // TextView mProgressText;
    // TextView mTrackingText;

    AdjustColorCompute mColorCompute;
    private LineChartView mChartView;
    public boolean CHANGE_BY_SLOPE = false;
    private int mLight = AdjustColorCompute.default_light;
    private int mContrast = AdjustColorCompute.default_contrast;
    private int mBcsh = AdjustColorCompute.default_bcsh;
    private Button mChangeImageButton;
    private Bitmap mCurrentBitmap;
    private Button mResetButton;
    static int REQ_CODE_CAMERA = 21;
    static int REQ_CODE_PICTURES = 20;
    private static final int MAX_LIGHT = 20;
    private static final int MAX_CONTRAST = 20;
    private static final int MAX_BCSH = 510;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*
		 * if (!(Build.MODEL.contains("rk") || Build.MODEL.contains("Rk") ||
		 * Build.MODEL.contains("RK"))){ return; }
		 */

        setContentView(R.layout.vop_display_adjust);

        mColorCompute = new AdjustColorCompute(this);

        mSeekBar_bright = (SeekBar) findViewById(R.id.seekBar_bright);
        mSeekBar_bright.setOnSeekBarChangeListener(this);
        mSeekBar_contrast = (SeekBar) findViewById(R.id.seekBar_contrast);
        mSeekBar_contrast.setOnSeekBarChangeListener(this);
        mSeekBar_gamma = (SeekBar) findViewById(R.id.seekBar_gamma);
        mSeekBar_gamma.setOnSeekBarChangeListener(this);
        mSeekBar_bcsh = (SeekBar) findViewById(R.id.seekBar_bcsh);
        mSeekBar_bcsh.setOnSeekBarChangeListener(this);
        mText_bright = (TextView) findViewById(R.id.bright_tile);
        mText_contrast = (TextView) findViewById(R.id.contrast_tile);
        mText_bcsh = (TextView) findViewById(R.id.bcsh_tile);
        // mProgressText = (TextView) findViewById(R.id.progress_bright);
        // mTrackingText = (TextView)findViewById(R.id.tracking_bright);
        mChangeImageButton = (Button) findViewById(R.id.change_image);
        mChangeImageButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent intent = new Intent();
				/* Open the page of select pictures and set the type to image */
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, REQ_CODE_PICTURES);
            }
        });

        mResetButton = (Button) findViewById(R.id.reset_btn);
        mResetButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                resetValues();
            }
        });

        Button bri_del = (Button) findViewById(R.id.bri_del);
        Button bri_add = (Button) findViewById(R.id.bri_add);
        Button con_del = (Button) findViewById(R.id.con_del);
        Button con_add = (Button) findViewById(R.id.con_add);
        Button bcsh_del = (Button) findViewById(R.id.bcsh_del);
        Button bcsh_add = (Button) findViewById(R.id.bcsh_add);
        bri_del.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (mLight > 0) {
                    mLight--;
                    textBrightShow();
                    clickBtnCommon();
                }
            }
        });
        bri_add.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (mLight < MAX_LIGHT) {
                    mLight++;
                    textBrightShow();
                    clickBtnCommon();
                }
            }
        });
        con_del.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (mContrast > 0) {
                    mContrast--;
                    textContrastShow();
                    clickBtnCommon();
                }
            }
        });
        con_add.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (mContrast < MAX_CONTRAST) {
                    mContrast++;
                    textContrastShow();
                    clickBtnCommon();
                }
            }
        });
        bcsh_del.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (mBcsh > 0) {
                    mBcsh--;
                    textBcshShow();
                    mSeekBar_bcsh.setProgress(mBcsh);
                    AdjustColorCompute.setBcsh(mBcsh);
                }
            }
        });
        bcsh_add.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (mBcsh < MAX_BCSH) {
                    mBcsh++;
                    textBcshShow();
                    mSeekBar_bcsh.setProgress(mBcsh);
                    AdjustColorCompute.setBcsh(mBcsh);
                }
            }
        });
        mChartView = (LineChartView) findViewById(R.id.chart_view);

        AdjustColorCompute.tryChmodNode();
        AdjustColorCompute.openBcsh();
        restorePref();
        // must be after restorePref function.

    }

    private void textBrightShow() {
        mText_bright.setText(getString(R.string.bright_label) + " val = "
                + mLight);
    }

    private void textContrastShow() {
        mText_contrast.setText(getString(R.string.contrast_label) + " val = "
                + mContrast);
    }

    private void textBcshShow() {
        mText_bcsh.setText(getString(R.string.bcsh_label) + " val = " + mBcsh);
    }

    private void clickBtnCommon() {
        mColorCompute.computeLUTData(mLight, mContrast);
        // mChartView.updateLineChart(k, progress);
        mChartView.updateLineChart(AdjustColorCompute.xrgb_map);

        mColorCompute.extendXRGBData();
        mColorCompute.writeToFile();
        mSeekBar_bright.setProgress(mLight);
        mSeekBar_contrast.setProgress(mContrast);
        // mProgressText
        // .setText(getString(R.string.light_value) + " = " + mLight
        // + ", " + getString(R.string.contrast_value) + " = "
        // + mContrast);
    }

    private void restorePref() {
        // TODO Auto-generated method stub
        SharedPreferences sp = getSharedPreferences(sSharedPreferencesKey,
                Context.MODE_PRIVATE);
        // mLight = sp.getInt(DB_LIGHT_VALUE, AdjustColorCompute.default_light);
        // mContrast = sp.getInt(DB_CONTRAST_VALUE,
        // AdjustColorCompute.default_contrast);
        mBcsh = sp.getInt(DB_BCSH_VALUE, AdjustColorCompute.default_bcsh);
        // set the seekbar progress
        // mSeekBar_bright.setProgress(mLight);
        // mSeekBar_contrast.setProgress(mContrast);
        mSeekBar_bcsh.setProgress(mBcsh);

        textBrightShow();
        textContrastShow();
        textBcshShow();

        // mColorCompute.computeLUTData(mLight, mContrast);
        AdjustColorCompute.setBcsh(mBcsh);
        Log.d(LineChartView.TAG, "default_light "
                + AdjustColorCompute.default_light + " contrast "
                + AdjustColorCompute.default_contrast);
    }

    private void resetValues() {
        // get property set about luminance and contrast .

        mSeekBar_bright.setProgress(AdjustColorCompute.default_light);
        mSeekBar_contrast.setProgress(AdjustColorCompute.default_contrast);
        mSeekBar_bcsh.setProgress(AdjustColorCompute.default_bcsh);

        mColorCompute.computeLUTData(AdjustColorCompute.default_light,
                AdjustColorCompute.default_contrast);
        mColorCompute.extendXRGBData();
        mColorCompute.writeToFile();
        AdjustColorCompute.setBcsh(AdjustColorCompute.default_bcsh);

        // mProgressText
        // .setText(getString(R.string.light_value) + " = " + mLight
        // + ", " + getString(R.string.contrast_value) + " = "
        // + mContrast);
    }

    private void saveValue() {
        SharedPreferences sp = getSharedPreferences(sSharedPreferencesKey,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putInt(DB_LIGHT_VALUE, mLight);
        editor.putInt(DB_CONTRAST_VALUE, mContrast);
        editor.putInt(DB_BCSH_VALUE, mBcsh);
        editor.commit();
    }

    public void onProgressChanged(SeekBar seekBar, int progress,
                                  boolean fromTouch) {
        switch (seekBar.getId()) {
            case R.id.seekBar_bright:
                AdjustColorCompute.USE_MAP_TABLE = true;
                mColorCompute.computeLUTData(progress, mContrast);
                mLight = progress;
                // mChartView.updateLineChart(k, progress);
                mChartView.updateLineChart(AdjustColorCompute.xrgb_map);
                textBrightShow();
                break;
            case R.id.seekBar_contrast:
                AdjustColorCompute.USE_MAP_TABLE = true;
                mColorCompute.computeLUTData(mLight, progress);
                mContrast = progress;
                mChartView.updateLineChart(AdjustColorCompute.xrgb_map);
                textContrastShow();
                break;
            case R.id.seekBar_gamma:
                if (progress < 10)
                    return;
                if (AdjustColorCompute.USE_MAP_TABLE)
                    AdjustColorCompute.USE_MAP_TABLE = false;

                mColorCompute.computeGamma(progress / 200.0f);
                mChartView.updateLineChart(AdjustColorCompute.xrgb_map);
                break;
            case R.id.seekBar_bcsh:
                mBcsh = progress;
                textBcshShow();
                AdjustColorCompute.setBcsh(mBcsh);
                break;
            default:
                break;
        }
        // float progress_label;
        // if (!AdjustColorCompute.USE_MAP_TABLE)
        // progress_label = progress / 200.0f;
        // else
        // progress_label = progress;
        // mProgressText.setText(progress_label + " "
        // + getString(R.string.seekbar_from_touch));

    }

    /*
     * (non-Javadoc)
     *
     * @see android.app.Activity#onStop()
     */
    @Override
    protected void onStop() {
        // TODO Auto-generated method stub
        saveValue();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        mColorCompute.data = null;
        mColorCompute.div_t = null;
        mColorCompute.light_t = null;
        saveValue();
        super.onDestroy();
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
        // mTrackingText.setText(getString(R.string.seekbar_tracking_on));
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
        // mTrackingText.setText(getString(R.string.seekbar_tracking_off));
        switch (seekBar.getId()) {
            case R.id.seekBar_bright:
            case R.id.seekBar_contrast:
                mColorCompute.extendXRGBData();
                mColorCompute.writeToFile();
                break;
        }
        // mProgressText
        // .setText(getString(R.string.light_value) + " = " + mLight
        // + ", " + getString(R.string.contrast_value) + " = "
        // + mContrast);
    }

    @SuppressWarnings("deprecation")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        if (resultCode == RESULT_OK) {
            Uri uri = data.getData();
            Log.e("uri", uri.toString());
            ContentResolver cr = this.getContentResolver();
            if (mCurrentBitmap != null) {
                mCurrentBitmap.recycle();
                mCurrentBitmap = null;
            }
            try {
                mCurrentBitmap = BitmapFactory.decodeStream(cr
                        .openInputStream(uri));
                ImageView imageView = (ImageView) findViewById(R.id.image_view);
				/* 将Bitmap设定到ImageView */
                imageView.setBackgroundDrawable(new BitmapDrawable(
                        mCurrentBitmap));
            } catch (FileNotFoundException e) {
                Log.e("Exception", e.getMessage(), e);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

}
