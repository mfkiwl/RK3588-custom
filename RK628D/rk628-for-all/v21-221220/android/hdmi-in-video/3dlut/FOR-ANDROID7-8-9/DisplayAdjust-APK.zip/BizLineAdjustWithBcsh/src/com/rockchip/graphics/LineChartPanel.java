package com.rockchip.graphics;

import android.content.Context;
import android.widget.FrameLayout;

public class LineChartPanel extends FrameLayout {

    public LineChartPanel(Context context) {
        super(context);
        // TODO Auto-generated constructor stub
    }

}
