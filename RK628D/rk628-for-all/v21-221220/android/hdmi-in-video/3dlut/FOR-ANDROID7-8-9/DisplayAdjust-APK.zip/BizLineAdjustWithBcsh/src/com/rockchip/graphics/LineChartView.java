package com.rockchip.graphics;


import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;

public class LineChartView extends SurfaceView implements Callback {

    private SurfaceHolder sfh;
    private Paint paint;
    private Canvas canvas;

    private Path path;
    public static String TAG = "LineChartView";
    private float mMainCoorSize = 4;
    private float mHintCoorSize = 1;
    private int mPadding;
    private int mBottom;
    private int mRight;
    private int mTop;
    private int mLeft;
    private int mStepY = 50;
    private int mStepX = 50;
    private Path mLinePath;
    public static int DRAW_LIGHT = 0;
    public static int DRAW_CONTRAST = 1;
    public static int DRAW_GAMMA = 2;

    AdjustColorCompute mComputation;
    private boolean mFirstCreated = true;
    private Path mOriginalLine;

    public LineChartView(Context context) {
        super(context);
        init();
    }

    public LineChartView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
        // this(context);
        // TODO Maybe some bug. ZHENGZHICAN
    }

    private void init() {
        sfh = getHolder();
        sfh.addCallback(this);

        path = new Path();
        mLinePath = new Path();
        mOriginalLine = new Path();

        mFirstCreated = true;

        //mComputation.computeLUTData(10, 10);
    }


    public AdjustColorCompute getComputation() {
        return mComputation;
    }

    public void setComputation(AdjustColorCompute computation) {
        this.mComputation = computation;
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width,
                               int height) {
        // TODO Auto-generated method stub

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // TODO Auto-generated method stub
        paint = new Paint();
        paint.setAntiAlias(true);
        //th.start();
        myDraw();
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right,
                            int bottom) {
        // TODO Auto-generated method stub
        super.onLayout(changed, left, top, right, bottom);
        mPadding = 15;
        int padding = mPadding;
        mLeft = getLeft() + padding;
        mTop = getTop();
        mRight = getRight() - padding;
        mBottom = getBottom() - getPaddingTop(); //TODO: It's a hack to " -20 ".
        if (mFirstCreated) {
            if (mFirstCreated) {
                mOriginalLine.reset();
                for (int i = 0; i < 256; i += 5) {
                    if (i == 0)
                        mOriginalLine.moveTo(mLeft + i, mBottom - i);
                    mOriginalLine.lineTo(mLeft + i, mBottom - i);
                }
            }
            updateLineChart(AdjustColorCompute.xrgb_map);
            mFirstCreated = false;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        // TODO Auto-generated method stub
        super.onDraw(canvas);
    }

    private void myDraw() {
        // TODO Auto-generated method stub
        canvas = sfh.lockCanvas();
        if (canvas != null) {
            canvas.drawColor(Color.argb(255, 0x33, 0x33, 0x33));
            drawCoordinate(canvas);
            // drawQpath(canvas);
            drawLine(canvas, mLeft, mBottom, mRight, mTop);
            sfh.unlockCanvasAndPost(canvas);
        }
    }

    @SuppressLint("UseValueOf")
    public void drawCoordinate(Canvas canvas) {
        int padding = mPadding;
        int left = mLeft;
        int top = mTop;
        int right = mRight;
        int bottom = mBottom;
        int stepX = mStepX;
        int stepY = mStepY;
        // Log.d(TAG, " stepX " + stepX + " stepY " + stepY);
        // canvas.translate(padding, padding);
        path.reset();
        paint.setStrokeWidth(mHintCoorSize);
        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.STROKE);
        //canvas.drawLine(left, bottom, right, bottom, paint);
        //canvas.drawLine(left, top, left, bottom, paint);
        int count = 0;
        for (int j = bottom; j > top; j -= stepY) {
            canvas.drawLine(left, j, right, j, paint);
            String y_num = new Integer(count++ * stepY).toString();
            canvas.drawText(y_num, left - padding, j, paint);
        }
        count = 0;
        for (int i = left; i < right; i += stepX) {
            canvas.drawLine(i, top, i, bottom, paint);
            if (0 == count) {
                count++;
                continue;
            }
            String x_num = new Integer(count++ * stepX).toString();
            canvas.drawText(x_num, i, bottom + padding, paint);
        }
        canvas.drawPath(mOriginalLine, paint);

        // paint.setColor(Color.RED);

        paint.setStyle(Paint.Style.FILL);
        Path path1 = new Path();
        path1.moveTo(right, bottom);
        path1.lineTo(right - 10, bottom - 10);
        path1.lineTo(right + 10, bottom);
        path1.lineTo(right - 10, bottom + 10);
        canvas.drawPath(path1, paint);

        path.moveTo(left, top);
        path.lineTo(left + 10, top + 10);
        path.lineTo(left, top - 10);
        path.lineTo(left - 10, top + 10);
        canvas.drawPath(path, paint);

        paint.setStyle(Paint.Style.STROKE);
    }

    public void drawLine(Canvas canvas, int left, int bottom, int right, int top) {
        // canvas.translate(padding, padding);
        // paint.setStrokeWidth(mMainCoorSize );
        paint.setColor(Color.BLUE);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(mMainCoorSize);

        canvas.drawPath(mLinePath, paint);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        paint = null;
    }

    public void updateLineChart(int[] xrgb_map) {
        // TODO Auto-generated method stub
        mLinePath.reset();
        for (int i = 0; i < 256; i += 5) {
            if (i == 0)
                mLinePath.moveTo(mLeft + i, mBottom - xrgb_map[i]);
            mLinePath.lineTo(mLeft + i, mBottom - xrgb_map[i]);
        }
        //post(this);
        myDraw();
    }
}
