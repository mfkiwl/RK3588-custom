package com.rockchip.graphics;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.text.DecimalFormat;

public class GpuDisplayAdjustActivity extends Activity implements View.OnClickListener, SeekBar.OnSeekBarChangeListener {

    private static final String SYS_GPU_HUE = "persist.sys.gpu.hue";
    private static final String SYS_GPU_SAT = "persist.sys.gpu.sat";
    private static final String SYS_GPU_R_GAIN = "persist.sys.gpu.r_gain";
    private static final String SYS_GPU_G_GAIN = "persist.sys.gpu.g_gain";
    private static final String SYS_GPU_B_GAIN = "persist.sys.gpu.b_gain";
    private static final String SYS_GPU_R_OFFEST = "persist.sys.gpu.r_offset";
    private static final String SYS_GPU_G_OFFEST = "persist.sys.gpu.g_offset";
    private static final String SYS_GPU_B_OFFEST = "persist.sys.gpu.b_offset";
    private static final String SYS_GPU_PQSTATE = "persist.sys.gpu.pq_state";
    private static final String SYS_HWC = "vendor.hwc.compose_policy";

    private Bitmap mCurrentBitmap;
    private TextView mTvHue, mTvSat, mTvRGain, mTvGGain, mTvBGain, mTvROffset, mTvGOffset, mTvBOffset;
    private SeekBar mSeekBarHue, mSeekBarSat, mSeekBarRGain, mSeekBarGGain, mSeekBarBGain, mSeekBarROffset, mSeekBarGOffset, mSeekBarBOffset;
    private Button mBtnHueAdd, mBtnHueDel, mBtnSatAdd, mBtnSatDel, mBtnRGainAdd, mBtnRGainDel, mBtnGGainAdd, mBtnGGainDel,
            mBtnBGainAdd, mBtnBGainDel, mBtnROffsetAdd, mBtnROffsetDel, mBtnGOffsetAdd, mBtnGOffsetDel, mBtnBOffsetAdd, mBtnBOffsetDel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.gpu_display_adjust);
        initUI();
        initValue();
    }

    private void initUI() {
        findViewById(R.id.change_image).setOnClickListener(this);
        mTvHue = (TextView) findViewById(R.id.hue_tile);
        mTvSat = (TextView) findViewById(R.id.saturation_title);
        mTvRGain = (TextView) findViewById(R.id.r_gain_title);
        mTvGGain = (TextView) findViewById(R.id.g_gain_title);
        mTvBGain = (TextView) findViewById(R.id.b_gain_title);
        mTvROffset = (TextView) findViewById(R.id.r_offset_title);
        mTvGOffset = (TextView) findViewById(R.id.g_offset_title);
        mTvBOffset = (TextView) findViewById(R.id.b_offset_title);
        mSeekBarHue = (SeekBar) findViewById(R.id.seekBar_hue);
        mSeekBarHue.setOnSeekBarChangeListener(this);
        mSeekBarSat = (SeekBar) findViewById(R.id.seekBar_saturation);
        mSeekBarSat.setOnSeekBarChangeListener(this);
        mSeekBarRGain = (SeekBar) findViewById(R.id.seekBar_r_gain);
        mSeekBarRGain.setOnSeekBarChangeListener(this);
        mSeekBarGGain = (SeekBar) findViewById(R.id.seekBar_g_gain);
        mSeekBarGGain.setOnSeekBarChangeListener(this);
        mSeekBarBGain = (SeekBar) findViewById(R.id.seekBar_b_gain);
        mSeekBarBGain.setOnSeekBarChangeListener(this);
        mSeekBarROffset = (SeekBar) findViewById(R.id.seekBar_r_offset);
        mSeekBarROffset.setOnSeekBarChangeListener(this);
        mSeekBarGOffset = (SeekBar) findViewById(R.id.seekBar_g_offset);
        mSeekBarGOffset.setOnSeekBarChangeListener(this);
        mSeekBarBOffset = (SeekBar) findViewById(R.id.seekBar_b_offset);
        mSeekBarBOffset.setOnSeekBarChangeListener(this);
        findViewById(R.id.hue_add).setOnClickListener(this);
        findViewById(R.id.hue_del).setOnClickListener(this);
        findViewById(R.id.saturation_add).setOnClickListener(this);
        findViewById(R.id.saturation_del).setOnClickListener(this);
        findViewById(R.id.r_gain_add).setOnClickListener(this);
        findViewById(R.id.r_gain_del).setOnClickListener(this);
        findViewById(R.id.g_gain_add).setOnClickListener(this);
        findViewById(R.id.g_gain_del).setOnClickListener(this);
        findViewById(R.id.b_gain_add).setOnClickListener(this);
        findViewById(R.id.b_gain_del).setOnClickListener(this);
        findViewById(R.id.r_offset_add).setOnClickListener(this);
        findViewById(R.id.r_offset_del).setOnClickListener(this);
        findViewById(R.id.g_offset_add).setOnClickListener(this);
        findViewById(R.id.g_offset_del).setOnClickListener(this);
        findViewById(R.id.b_offset_add).setOnClickListener(this);
        findViewById(R.id.b_offset_del).setOnClickListener(this);
        findViewById(R.id.btn_close_hwc).setOnClickListener(this);
        findViewById(R.id.btn_reset).setOnClickListener(this);
    }

    private void initValue() {
        float hue = Float.parseFloat(SystemProperties.get(SYS_GPU_HUE, "0.0"));
        mSeekBarHue.setProgress((int) (hue * 10 + 300));
        mTvHue.setText(getString(R.string.hue_label) + " " + hue);
        float sat = Float.parseFloat(SystemProperties.get(SYS_GPU_SAT, "1.00"));
        mSeekBarSat.setProgress((int) (sat * 50));
        mTvSat.setText(getString(R.string.saturation_label) + " " + sat);
        float rGain = Float.parseFloat(SystemProperties.get(SYS_GPU_R_GAIN, "1.00"));
        mSeekBarRGain.setProgress((int) (rGain * 50));
        mTvRGain.setText(getString(R.string.r_gain_label) + " " + rGain);
        float gGain = Float.parseFloat(SystemProperties.get(SYS_GPU_G_GAIN, "1.00"));
        mSeekBarGGain.setProgress((int) (gGain * 50));
        mTvGGain.setText(getString(R.string.g_gain_label) + " " + gGain);
        float bGain = Float.parseFloat(SystemProperties.get(SYS_GPU_B_GAIN, "1.00"));
        mSeekBarBGain.setProgress((int) (bGain * 50));
        mTvBGain.setText(getString(R.string.b_gain_label) + " " + bGain);
        float rOffset = Float.parseFloat(SystemProperties.get(SYS_GPU_R_OFFEST, "0"));
        mSeekBarROffset.setProgress((int) (rOffset + 32));
        mTvROffset.setText(getString(R.string.r_offset_label) + " " + rOffset);
        float gOffset = Float.parseFloat(SystemProperties.get(SYS_GPU_G_OFFEST, "0"));
        mSeekBarGOffset.setProgress((int) (gOffset + 32));
        mTvGOffset.setText(getString(R.string.g_offset_label) + " " + gOffset);
        float bOffset = Float.parseFloat(SystemProperties.get(SYS_GPU_B_OFFEST, "0"));
        mSeekBarBOffset.setProgress((int) (bOffset + 32));
        mTvBOffset.setText(getString(R.string.b_offset_label) + " " + bOffset);
    }


    @Override
    public void onClick(View view) {
        int value = 0;
        switch (view.getId()) {
            case R.id.change_image:
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, BizLineAdjustActivity.REQ_CODE_PICTURES);
                break;
            case R.id.hue_add:
                value = mSeekBarHue.getProgress();
                value++;
                if (value >= mSeekBarHue.getMax())
                    value = mSeekBarHue.getMax();

                mSeekBarHue.setProgress(value);
                break;
            case R.id.hue_del:
                value = mSeekBarHue.getProgress();
                value--;
                if (value <= 0)
                    value = 0;
                mSeekBarHue.setProgress(value);
                break;
            case R.id.saturation_add:
                value = mSeekBarSat.getProgress();
                value++;
                if (value >= mSeekBarSat.getMax())
                    value = mSeekBarSat.getMax();

                mSeekBarSat.setProgress(value);
                break;
            case R.id.saturation_del:
                value = mSeekBarSat.getProgress();
                value--;
                if (value <= 0)
                    value = 0;
                mSeekBarSat.setProgress(value);
                break;
            case R.id.r_gain_add:
                value = mSeekBarRGain.getProgress();
                value++;
                if (value >= mSeekBarRGain.getMax())
                    value = mSeekBarRGain.getMax();

                mSeekBarRGain.setProgress(value);
                break;
            case R.id.r_gain_del:
                value = mSeekBarRGain.getProgress();
                value--;
                if (value <= 0)
                    value = 0;
                mSeekBarRGain.setProgress(value);
                break;
            case R.id.g_gain_add:
                value = mSeekBarGGain.getProgress();
                value++;
                if (value >= mSeekBarGGain.getMax())
                    value = mSeekBarGGain.getMax();

                mSeekBarGGain.setProgress(value);
                break;
            case R.id.g_gain_del:
                value = mSeekBarGGain.getProgress();
                value--;
                if (value <= 0)
                    value = 0;
                mSeekBarGGain.setProgress(value);
                break;
            case R.id.b_gain_add:
                value = mSeekBarBGain.getProgress();
                value++;
                if (value >= mSeekBarBGain.getMax())
                    value = mSeekBarBGain.getMax();

                mSeekBarBGain.setProgress(value);
                break;
            case R.id.b_gain_del:
                value = mSeekBarBGain.getProgress();
                value--;
                if (value <= 0)
                    value = 0;
                mSeekBarBGain.setProgress(value);
                break;
            case R.id.r_offset_add:
                value = mSeekBarROffset.getProgress();
                value++;
                if (value >= mSeekBarROffset.getMax())
                    value = mSeekBarROffset.getMax();

                mSeekBarROffset.setProgress(value);
                break;
            case R.id.r_offset_del:
                value = mSeekBarROffset.getProgress();
                value--;
                if (value <= 0)
                    value = 0;
                mSeekBarROffset.setProgress(value);
                break;
            case R.id.g_offset_add:
                value = mSeekBarGOffset.getProgress();
                value++;
                if (value >= mSeekBarGOffset.getMax())
                    value = mSeekBarGOffset.getMax();

                mSeekBarGOffset.setProgress(value);
                break;
            case R.id.g_offset_del:
                value = mSeekBarGOffset.getProgress();
                value--;
                if (value <= 0)
                    value = 0;
                mSeekBarGOffset.setProgress(value);
                break;
            case R.id.b_offset_add:
                value = mSeekBarBOffset.getProgress();
                value++;
                if (value >= mSeekBarBOffset.getMax())
                    value = mSeekBarBOffset.getMax();

                mSeekBarBOffset.setProgress(value);
                break;
            case R.id.b_offset_del:
                value = mSeekBarBOffset.getProgress();
                value--;
                if (value <= 0)
                    value = 0;
                mSeekBarBOffset.setProgress(value);
                break;
            case R.id.btn_close_hwc:
                Log.d("lytest", "btn_close_hwc");
                SystemProperties.set(SYS_HWC, "0");
                break;
            case R.id.btn_reset:
                reset();
                break;
        }
    }

    private void reset() {
        mSeekBarHue.setProgress(300);
        mTvHue.setText(getString(R.string.hue_label) + " 0.0");
        mSeekBarSat.setProgress(50);
        mTvSat.setText(getString(R.string.saturation_label) + " 1.00");
        mSeekBarRGain.setProgress(50);
        mTvRGain.setText(getString(R.string.r_gain_label) + " 1.00");
        mSeekBarGGain.setProgress(50);
        mTvGGain.setText(getString(R.string.g_gain_label) + " 1.00");
        mSeekBarBGain.setProgress(50);
        mTvBGain.setText(getString(R.string.b_gain_label) + " 1.00");
        mSeekBarROffset.setProgress(32);
        mTvROffset.setText(getString(R.string.r_offset_label) + " 0");
        mSeekBarGOffset.setProgress(32);
        mTvGOffset.setText(getString(R.string.g_offset_label) + " 0");
        mSeekBarBOffset.setProgress(32);
        mTvBOffset.setText(getString(R.string.b_offset_label) + " 0");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        if (resultCode == RESULT_OK) {
            Uri uri = data.getData();
            ContentResolver cr = this.getContentResolver();
            if (mCurrentBitmap != null) {
                mCurrentBitmap.recycle();
                mCurrentBitmap = null;
            }
            try {
                mCurrentBitmap = BitmapFactory.decodeStream(cr
                        .openInputStream(uri));
                ImageView imageView = (ImageView) findViewById(R.id.image_view);
                /* 将Bitmap设定到ImageView */
                imageView.setBackgroundDrawable(new BitmapDrawable(
                        mCurrentBitmap));
            } catch (FileNotFoundException e) {
                Log.e("Exception", e.getMessage(), e);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        String value = null;
        switch (seekBar.getId()) {
            case R.id.seekBar_hue:
                //更新属性值
                value = formatValue((float) (i - 300) / 10, 1);
                if (!value.equals(SystemProperties.get(SYS_GPU_HUE, "0.0"))) {
                    SystemProperties.set(SYS_GPU_HUE, value);
                    SystemProperties.set(SYS_GPU_PQSTATE, String.valueOf(Integer.parseInt(SystemProperties.get(SYS_GPU_PQSTATE, "0")) + 1));
                }
                //属性值更新后需要刷新UI才能更新显示效果
                mTvHue.setText(getString(R.string.hue_label) + " " + value);
                break;
            case R.id.seekBar_saturation:
                value = formatValue((float) i / 50, 2);
                if (!value.equals(SystemProperties.get(SYS_GPU_SAT, "1.0"))) {
                    SystemProperties.set(SYS_GPU_SAT, value);
                    SystemProperties.set(SYS_GPU_PQSTATE, String.valueOf(Integer.parseInt(SystemProperties.get(SYS_GPU_PQSTATE, "0")) + 1));
                }
                mTvSat.setText(getString(R.string.saturation_label) + " " + value);
                break;
            case R.id.seekBar_r_gain:
                value = formatValue((float) i / 50, 2);
                if (!value.equals(SystemProperties.get(SYS_GPU_R_GAIN, "1.0"))) {
                    SystemProperties.set(SYS_GPU_R_GAIN, value);
                    SystemProperties.set(SYS_GPU_PQSTATE, String.valueOf(Integer.parseInt(SystemProperties.get(SYS_GPU_PQSTATE, "0")) + 1));
                }
                mTvRGain.setText(getString(R.string.r_gain_label) + " " + value);
                break;
            case R.id.seekBar_g_gain:
                value = formatValue((float) i / 50, 2);
                if (!value.equals(SystemProperties.get(SYS_GPU_G_GAIN, "1.0"))) {
                    SystemProperties.set(SYS_GPU_G_GAIN, value);
                    SystemProperties.set(SYS_GPU_PQSTATE, String.valueOf(Integer.parseInt(SystemProperties.get(SYS_GPU_PQSTATE, "0")) + 1));
                }
                mTvGGain.setText(getString(R.string.g_gain_label) + " " + value);
                break;
            case R.id.seekBar_b_gain:
                value = formatValue((float) i / 50, 2);
                if (!value.equals(SystemProperties.get(SYS_GPU_B_GAIN, "1.0"))) {
                    SystemProperties.set(SYS_GPU_B_GAIN, value);
                    SystemProperties.set(SYS_GPU_PQSTATE, String.valueOf(Integer.parseInt(SystemProperties.get(SYS_GPU_PQSTATE, "0")) + 1));
                }
                mTvBGain.setText(getString(R.string.b_gain_label) + " " + value);
                break;
            case R.id.seekBar_r_offset:
                value = String.valueOf(i - 32);
                if (!value.equals(SystemProperties.get(SYS_GPU_R_OFFEST, "0"))) {
                    SystemProperties.set(SYS_GPU_R_OFFEST, value);
                    SystemProperties.set(SYS_GPU_PQSTATE, String.valueOf(Integer.parseInt(SystemProperties.get(SYS_GPU_PQSTATE, "0")) + 1));
                }
                mTvROffset.setText(getString(R.string.r_offset_label) + " " + value);
                break;
            case R.id.seekBar_g_offset:
                value = String.valueOf(i - 32);
                if (!value.equals(SystemProperties.get(SYS_GPU_G_OFFEST, "0.0"))) {
                    SystemProperties.set(SYS_GPU_G_OFFEST, value);
                    SystemProperties.set(SYS_GPU_PQSTATE, String.valueOf(Integer.parseInt(SystemProperties.get(SYS_GPU_PQSTATE, "0")) + 1));
                }
                mTvGOffset.setText(getString(R.string.g_offset_label) + " " + value);
                break;
            case R.id.seekBar_b_offset:
                value = String.valueOf(i - 32);
                if (!value.equals(SystemProperties.get(SYS_GPU_B_OFFEST, "0.0"))) {
                    SystemProperties.set(SYS_GPU_B_OFFEST, value);
                    SystemProperties.set(SYS_GPU_PQSTATE, String.valueOf(Integer.parseInt(SystemProperties.get(SYS_GPU_PQSTATE, "0")) + 1));
                }
                mTvBOffset.setText(getString(R.string.b_offset_label) + " " + value);
                break;
        }

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    private String formatValue(float value, int digit) {
/*        DecimalFormat df = new DecimalFormat("#.0");
        return df.format(value);*/
        if (digit == 1) {
            return String.format("%.1f", value);
        } else {
            return String.format("%.2f", value);
        }
    }
}
