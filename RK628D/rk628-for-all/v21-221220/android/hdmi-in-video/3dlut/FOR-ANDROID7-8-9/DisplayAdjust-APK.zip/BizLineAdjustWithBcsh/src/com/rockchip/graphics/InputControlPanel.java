package com.rockchip.graphics;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;

public class InputControlPanel extends ViewGroup {

    public InputControlPanel(Context context, AttributeSet attrs) {
        super(context, attrs);
        // TODO Auto-generated constructor stub
    }

    @Override
    protected void onLayout(boolean arg0, int arg1, int arg2, int arg3, int arg4) {
        // TODO Auto-generated method stub

    }

}
