/*
 * Copyright 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

//#define LOG_NDEBUG 0
#include <sys/system_properties.h>
#include "RkTextureCalculate.h"

#define PROPERTY_VALUE_MAX 128

namespace android {
namespace RE {
namespace impl {
    
RkTextureCalculate::RkTextureCalculate() {}

void RkTextureCalculate::screen_calibre(uint8_t *tab)
{
    float hue = get_persist_sys_gpu(0, gpu_hue);
    float sat = get_persist_sys_gpu(1.0f, gpu_sat);
    float r_gain = get_persist_sys_gpu(1.0f, gpu_r_gain);
    float g_gain = get_persist_sys_gpu(1.0f, gpu_g_gain);
    float b_gain = get_persist_sys_gpu(1.0f, gpu_b_gain);
    float r_offset = get_persist_sys_gpu(0, gpu_r_offset);
    float g_offset = get_persist_sys_gpu(0, gpu_g_offset);
    float b_offset = get_persist_sys_gpu(0, gpu_b_offset);
    
    double a[9] = {};
    
    float cos_hue_radians = cos(convert_angles_to_radians(hue));
    ALOGI("---zc--- cos_hue_radians:%f \n", cos_hue_radians);
    float sin_hue_radians = sin(convert_angles_to_radians(hue));
    ALOGI("---zc--- sin_hue_radians:%f \n", sin_hue_radians);
    
    a[0] = r_gain * (0.92 * sat * cos(convert_angles_to_radians(hue)) + 0.21 * sat * sin(convert_angles_to_radians(hue)) + 0.21);
    a[1] = r_gain * (0.68 * sat * sin(convert_angles_to_radians(hue)) - 0.80 * sat * cos(convert_angles_to_radians(hue)) + 0.69);
    a[2] = -1 * (r_gain * (0.08 * sat * cos(convert_angles_to_radians(hue)) + 0.92 * sat * sin(convert_angles_to_radians(hue)) - 0.07));
    a[3] = -1 * (g_gain * (0.25 * sat * cos(convert_angles_to_radians(hue)) + 0.17 * sat * sin(convert_angles_to_radians(hue)) - 0.21));
    a[4] = g_gain * (0.32 * sat * cos(convert_angles_to_radians(hue)) - 0.11 * sat * sin(convert_angles_to_radians(hue)) + 0.69);
    a[5] = g_gain * (0.28 * sat * sin(convert_angles_to_radians(hue)) - 0.08 * sat * cos(convert_angles_to_radians(hue)) + 0.07);
    a[6] = b_gain * (1.08 * sat * sin(convert_angles_to_radians(hue)) - 0.25 * sat * cos(convert_angles_to_radians(hue)) + 0.21);
    a[7] = -1 * (b_gain * (0.80 * sat * cos(convert_angles_to_radians(hue)) + 0.95 * sat * sin(convert_angles_to_radians(hue)) - 0.69));
    a[8] = b_gain * (1.08 * sat * cos(convert_angles_to_radians(hue)) - 0.10 * sat * sin(convert_angles_to_radians(hue)) + 0.07);
    for (int i = 0; i < 9; i++) {
        ALOGI("---zc--- a[%d]:%f \n", i, a[i]);
    }
	double c[3] = {};
    c[0] = (double)r_offset;
    c[1] = (double)g_offset;
    c[2] = (double)b_offset;
	double gamma[] = {1, 1, 1};

	int dim = 64;

	#define CLIP(a, min, max)       \
                 (((a) < (min)) ? (min) : (((a) > (max)) ? (max) : (a)))

	for (int b = 0; b < dim; ++b) {
		for (int g = 0; g < dim; ++g) {
			for (int r = 0; r < dim; ++r) {
				int bidx = b * dim * dim + g * dim + r;
				int idx = bidx * 3;

				double rr = r / 63.0f;
				double gg = g / 63.0f;
				double bb = b / 63.0f;
				
				double rp = pow(rr, gamma[0]);
				double gp = pow(gg, gamma[1]);
				double bp = pow(bb, gamma[2]);

				double ro = rp * a[0] + gp * a[1] + bp * a[2];
				double go = rp * a[3] + gp * a[4] + bp * a[5];
				double bo = rp * a[6] + gp * a[7] + bp * a[8];

				tab[idx] = CLIP(ro * 255 + c[0], 0, 255);
				tab[idx + 1] = CLIP(go * 255 + c[1], 0, 255);
				tab[idx + 2] = CLIP(bo * 255 + c[2], 0, 255);
			}
		}
	}
    for (int i = 0; i < dim; ++i) {
		int idx = i * dim * dim + i * dim + i;
		int v = CLIP(i * 255.0 / 63.0, 0, 255);

		idx *= 3;
		
		tab[idx] = v;
		tab[idx + 1] = v;
		tab[idx + 2] = v;
	}
}

void RkTextureCalculate::sat_tuning(uint8_t *tab) {
    int dim = 64;

	int protect_en = get_protect_state();
	float enh = get_enh_value();
	float adp_coef = enh;
    
	#define RKMIN(a, b)             (((a) < (b)) ? (a) : (b))
	#define RKMAX(a, b)             (((a) > (b)) ? (a) : (b))
	#define RKMIN3(a, b, c)         RKMIN(RKMIN(a, b), (c))
	#define RKMAX3(a, b, c)         RKMAX(RKMAX(a, b), (c))
	//#define CLIP(a, min, max)       \
                 //((a) < (min)) ? (min) : (((a) > (max)) ? (max) : (a))

	for (int b = 0; b < dim; ++b) {
		for (int g = 0; g < dim; ++g) {
			for (int r = 0; r < dim; ++r) {
				int bidx = b * dim * dim + g * dim + r;
				int idx = bidx * 3;

				int rr = (int)(r * 255.0f / 63.0f);
				int gg = (int)(g * 255.0f / 63.0f);
				int bb = (int)(b * 255.0f / 63.0f);

				int cmax = RKMAX3(rr, gg, bb);
				int cmin = RKMIN3(rr, gg, bb);
				int gray = (rr + gg + bb + 1) / 3;

				if (protect_en) {
					float lim_cmax = (cmax != gray) ? (255 - gray) * 1.0f / (cmax - gray) : enh;
					float lim_cmin = (cmin != gray) ? gray * 1.0f / (gray - cmin) : enh;

					adp_coef = RKMIN3(enh, lim_cmax, lim_cmin);
				}

				rr = (rr - gray) * adp_coef + gray;
				gg = (gg - gray) * adp_coef + gray;
				bb = (bb - gray) * adp_coef + gray;
                
				tab[idx] = CLIP(rr, 0, 255);
				tab[idx + 1] = CLIP(gg, 0, 255);
				tab[idx + 2] = CLIP(bb, 0, 255);
			}
		}
	}
}

float RkTextureCalculate::get_enh_value() {
	char prop_value[PROPERTY_VALUE_MAX];
	float enh = 2.0f;

	if (__system_property_get("sys.param_set.enh", prop_value)) {
		if (strlen(prop_value) > 0) {
			enh = atof(prop_value);
		}
	}
	return enh;
}

int RkTextureCalculate::get_protect_state() {
	char prop_value[PROPERTY_VALUE_MAX];
	int en = 1;

	if (__system_property_get("sys.param_set.protect_en", prop_value)) {
		if (strlen(prop_value) > 0) {
			en = atof(prop_value);
		}
	}
	return en;
}

float RkTextureCalculate::get_persist_sys_gpu(float default_value, const char *sys_property) {
	char prop_value[PROPERTY_VALUE_MAX];
	float en = default_value;

	if (__system_property_get(sys_property, prop_value)) {
		if (strlen(prop_value) > 0) {
			en = atof(prop_value);
		}
	}
	return en;
}

bool RkTextureCalculate::set_persist_sys_gpu(const char *sys_value, const char *sys_property) {
	if (__system_property_set(sys_property, sys_value) == 0) {
		return true;
	}
    return false;
}

float RkTextureCalculate::convert_angles_to_radians(float angles) {
	float radians = 0;
    if(angles != 0)
        radians = 3.14 * angles / 180;
	return radians;
}

} // namespace impl
} // namespace RE
} // namespace android
