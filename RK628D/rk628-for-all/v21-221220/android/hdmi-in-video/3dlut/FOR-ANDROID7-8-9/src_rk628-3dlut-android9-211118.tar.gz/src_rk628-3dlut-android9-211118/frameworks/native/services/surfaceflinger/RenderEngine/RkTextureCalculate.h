#pragma once

#include <string> 
#include <stdlib.h>
#include <utils/Log.h>
#include <stdint.h>
#include <math.h>

namespace android {
namespace RE {
namespace impl {
    
class GLESRenderEngine;

class RkTextureCalculate {
    public:
        RkTextureCalculate();
        void screen_calibre(uint8_t *tab);
        void sat_tuning(uint8_t *tab);
        float get_enh_value();
        int get_protect_state();
        float get_persist_sys_gpu(float default_value, const char *sys_property);
        bool set_persist_sys_gpu(const char *sys_value, const char *sys_property);
        float convert_angles_to_radians(float angles);
        const char *gpu_hue = "persist.sys.gpu.hue";
        const char *gpu_sat = "persist.sys.gpu.sat";
        const char *gpu_r_gain = "persist.sys.gpu.r_gain";
        const char *gpu_g_gain = "persist.sys.gpu.g_gain";
        const char *gpu_b_gain = "persist.sys.gpu.b_gain";
        const char *gpu_r_offset = "persist.sys.gpu.r_offset";
        const char *gpu_g_offset = "persist.sys.gpu.g_offset";
        const char *gpu_b_offset = "persist.sys.gpu.b_offset";
        const char *gpu_pq_state = "persist.sys.gpu.pq_state";
};

} // namespace impl
} // namespace RE
} // namespace android
